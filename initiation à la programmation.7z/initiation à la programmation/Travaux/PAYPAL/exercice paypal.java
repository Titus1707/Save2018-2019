
package javaapplication13;

import java.util.Scanner;

public class JavaApplication13 {

    
    public static void main(String[] args) {
    
// Déclaration variables
    
    float vente,commfixe,commvariable,receteVendeur,commission;
    
    // assignation variables
    
    commfixe = 0.35f ;   // commision fixe
    commvariable = 0.034f;        // commision variable
            
    
    // affichage du titre 
            
        receteVendeur = (vente-commfixe)-(vente*commvariable); // assigne à recete Vendeur les ventes - les commisions
        
        // affiche le titre déduction paypal 
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("-----Déduction paypal---");
        System.out.println("----------------------------------------------------------------------------");
        
        // affiche le total paypal
            System.out.println("Le total percu par paypal est de :");
            System.out.println(vente-receteVendeur); 
        
         // ligne de séparation esthétique
        System.out.println("----------------------------------------------------------------------------");
        
        // affiche le total des ventes déduit de la marge paypal
            System.out.println("Le total des ventes déduit de la marge paypal est de :");
            System.out.println(vente-(vente-receteVendeur)); 
                  
                        } // end if
 
    // condition d'innexistance (else)
    else{
   
            System.out.println("trop petit"); // affiche trop petit si ventes trop faibles
    
    
        }
        
    }
    
}
