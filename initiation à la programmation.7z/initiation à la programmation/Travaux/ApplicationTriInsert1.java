
package tri_par_insertion;
/**
 *
 *Gil Van Cayseele ISA
 */
public class  ApplicationTriInsert1
{
  // le tableau è trier:
  static  Double [] table  =  new  Double [10]  ;

 public static void  main ( String [ ] args )
{
   Initialisation   ( );
   System.out.println ("Tableau initial :");
   Impression  ( );
   TriInsert  ( );
   System.out.println ("Tableau une fois trié :");
   Impression  ( );
   System.out.println ("-------------------");
 }

 static void  TriInsert  ( )
{
   // sous-programme de Tri par insertion :
   double  n  =  table.length - 1 ; // taille du tableau
  for (  int  i  =  2 ;  i  <=  n ;  i ++ )
  {
    double  v  =  table[i] ;
    int  j  =  i ;
   while ( table[ j - 1 ]  >  v )
   { // travail sur la partie déjè triée (a1, a2, ... , ai)
     table[ j ]  =  table[ j - 1 ] ;  // on décale l'élément
     j -- ;   // on passe au rang précédent
    }
    table[ j ]   =  v  ;  //on recopie ai dans la place libérée
   }
 }

  static void  Impression  ( )
{
   // Affichage du tableau
   int  n  =  table.length - 1 ;
  for (  int  i  =  0 ;  i <= n ;  i ++ )
    System.out.print ( table[i] + " , ");
   System.out.println ();
 }

 static void  Initialisation   ( )
{
   // remplissage aléatoire du tableau
   double  n  =  table.length - 1 ;
  for (  int  i  =  1 ;  i <= n ;  i ++ )
    table[i]  =  ( double )( Math.random () * 100 );
   //sentinelle à l'indice 0 :
  // table[0]  = - Integer.MAX_VALUE ;  // attention la valeur max de l'entier est ici
 }

}
