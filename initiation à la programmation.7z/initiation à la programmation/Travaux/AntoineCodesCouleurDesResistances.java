package codes.couleur.des.résistances;
//@AntoineFastenaekens
import java.util.*;

public class CodesCouleurDesRésistances 
{
    public static void main(String[] args) 
    {
        Scanner lectureClavier = new Scanner(System.in);
        
        String couleur1;
        String couleur2;
        String couleur3;
        String couleur4;
        
        float valeur1 = 0f;
        float valeur2 = 0f; 
        float valeur3 = 0f; /*Multiplicateur*/ 
        float valeur4 = 0f; /*Tolérence     */
        float resultat = 0f;

        float cNoir     = 0f;
        float cMarron   = 1f;
        float cRouge    = 2f;
        float cOrange   = 3f;           
        float cJaune    = 4f;         
        float cVert     = 5f;        
        float cBleu     = 6f;       
        float cViolet   = 7f;          
        float cGris     = 8f;      
        float cBlanc    = 9f;
        
        int erreur =1 ;

        do 
        {
            erreur = 0 ;
            System.out.println("Entre la couleur de la 1er bande : ");
            couleur1 = lectureClavier.next();
            couleur1 = couleur1.toLowerCase();
 
            switch (couleur1)
            {
               case "marron":
                    valeur1 = cMarron*10;
                    break;
                case "rouge":
                    valeur1 = cRouge*10;
                    break;
                case "orange":
                    valeur1 = cOrange*10;
                    break;
                case "jaune":
                    valeur1 = cJaune*10;
                    break; 
                case "vert":
                    valeur1 = cVert*10;
                    break;
                case "bleu":
                    valeur1 = cBleu*10;
                    break;
                case "violet":
                    valeur1 = cViolet*10;
                    break;
                case "gris":
                    valeur1 = cGris*10;
                    break;
                case "blanc":
                    valeur1 = cBlanc*10;
                    break;
              
            default :
        
            System.out.println("Erreur");
            erreur = 1;
            }
        
            System.out.println(valeur1);
        }
        while ( erreur == 1 );

        
        do
        {
            erreur = 0 ;
            System.out.println("Entre la couleur de la 2e bande : ");
            couleur2 = lectureClavier.next(); 
            couleur2 = couleur2.toLowerCase();
                
            switch (couleur2)
           {
            case "noir":
                   valeur2 = cNoir;
                  break;           
            case "marron":
                  valeur2 = cMarron;
                break;  
            case "rouge":
                valeur2 = cRouge;
                break;
            case "orange":
                valeur2 = cOrange;
                break;
            case "jaune":
                valeur2 = cJaune;
                break;
            case "vert":
                valeur2 = cVert;
                break;
            case "bleu":
                valeur2 = cBleu;
                break;
            case "violet":
                valeur2 = cViolet;
                break;       
            case "gris":
                valeur2 = cGris;
                break;
            case "blanc":
                valeur2 = cBlanc;
                break;
            
            
            default :
                System.out.println("Erreur2");
                erreur = 1;
            }
        }
        while ( erreur == 1 );
                        
        System.out.println(valeur2);

        do
        {
           erreur = 0 ;
            System.out.println("Entre la couleur de la 3e bande : ");
            couleur3 = lectureClavier.next(); 
            couleur3 = couleur3.toLowerCase();
 
            switch (couleur3)
            {
            case "noir":
                valeur3 = (float) Math.pow(10, cNoir); 
                break;    
            case "marron":
                valeur3 = (float) Math.pow(10, cMarron);
                break;
            case "rouge":
                valeur3 = (float) Math.pow(10, cRouge);
                break;
            case "orange":
                valeur3 = (float) Math.pow(10, cOrange);
                break;
            case "jaune":
                valeur3 = (float) Math.pow(10, cJaune);
                break;
            case "vert":
                valeur3 = (float) Math.pow(10, cVert);
                break; 
            case "bleu":
                valeur3 = (float) Math.pow(10, cBleu);
                break;
            case "violet":
                valeur3 = (float) Math.pow(10, cViolet);
                break;
            case "gris":
                valeur3 = (float) Math.pow(10, cGris);
                break;
            case "blanc":
                valeur3 = (float) Math.pow(10, cBlanc);
                break;
            case "or":
                valeur3 = 10f;
                break;
            case "argent":
                valeur3 = 100f;
                break;
                  
            default :
                System.out.println("Erreur3");
                erreur = 1;
            }
        }
        while ( erreur == 1 );
        
        System.out.println(valeur3);
        
        do
        {
            erreur = 0 ;                
            System.out.println("Entre la couleur de la 4e bande : ");
            couleur4 = lectureClavier.next(); 
            couleur4 = couleur4.toLowerCase();
 
            switch (couleur4)
            {
            case "marron":
                valeur4 = cMarron;
                break;
            case "rouge":
                valeur4 = cRouge;
                break;
            case "orange":
                valeur4 = cOrange;
                break;
            case "jaune":
                valeur4 = cJaune;
                break;
            case "vert":
                valeur4 = 0.5f;
                break;
            case "bleu":
                valeur4 = 0.25f;
                break;
            case "violet":
                valeur4 = 0.10f;
                break;
            case "gris":
                valeur4 = 0.05f;
                break;
            case "or":
                valeur4 = 5f;
                break;
            case "argent":
                valeur4 = 10f;
                break;
                  
            default :
                System.out.println("Erreur4");
                erreur = 1;
            }
        }
        while ( erreur == 1 );
        
        switch (couleur3)
        {
            case "or":
                resultat = (valeur1 + valeur2)+ valeur3;
                break;
            case "argent" :
                resultat = (valeur1 + valeur2)+ valeur3;
                break;
                
            default :
                resultat = (valeur1 + valeur2)* valeur3;
        }
        
        String ohm = "\u2126";
        if (resultat > 1000000)
        {
            System.out.println(resultat/1000000 +" M " + ohm + " à " + valeur4 +" % près");
        }
        else 
        {
            if (resultat > 1000)
            {
                System.out.println(resultat/1000 +" K " + ohm + " à " + valeur4 +" % près");
            }
            else // Resultat < 1 000
            {
                System.out.println(resultat + " " + ohm + " à " + valeur4 +" % près");
            }
        }
        lectureClavier.close();
    }
}
