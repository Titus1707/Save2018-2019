/*
// calendrier , user entre la date et donne le jour
*/

package calendrier1;
import java.util.Scanner;

public class Calendrier1 
{          
    public static void main(String[] args) 
    {
        // classe scaner
        Scanner lectureClavier = new Scanner(System.in);
        // ASSIGNATION DES VARIABLES
        int jour=0;
        int mois= 0;
        int annee=0;
        // valeur maximale et min pour les jours 
        int jourmax = 31;
        int jourmin=1;
        int moismax = 12;
        int moismin=0;
        int anneemax = 2020;
        int anneemin=2000;
        String anneevaleur = "";
                
        // calcul de la date du jour 
        
        // acceuil 
        System.out.println("/////////////////////////////////");
        System.out.println("Programme de calendrier, veuillez entrer la date recherchée");
         
        System.out.println("/////////////////////////////////");
        
        // entrée du jour 
        System.out.println("---->  Entrez le jour  <----");
        System.out.println("/////////////////////////////////");
         
        //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        jour = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + jour);
        
        // entrée du mois 
        
        System.out.println("---->  Entrez le mois  <----");
        System.out.println("/////////////////////////////////");
         
         //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        mois = lectureClavier.nextInt();  // lire le premier mot 

        System.out.println("Vous avez saisi le nombre : " + mois);
        
        // entrée de l'année 
        
        System.out.println("---->  Entrez l'année  <----");
        System.out.println("/////////////////////////////////");
         
         //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        annee = lectureClavier.nextInt();  // lire le premier mot 

        System.out.println("Vous avez saisi le nombre : " + annee+anneevaleur);
       
        if(jour > jourmax || jour < jourmin){
            jour = 0;
            System.out.println("cette valeur est incorrecte,la valeur est trop haute rééseyez...");
            System.out.println("entrez le jour");
            System.out.println("Veuillez saisir un nombre compris entre 1 et 31 :");
            jour = lectureClavier.nextInt();  // lire le premier mot 
            System.out.println("Vous avez saisi le nombre : " + jour);

      
        
        } // fin de condition d'erreur N°2 
    
            if(mois > moismax || mois < moismin){
        mois = 0;
        System.out.println("cette valeur est incorrecte,la valeur est trop haute rééseyez...");
        System.out.println("entrez le mois");
        System.out.println("Veuillez saisir un nombre compris entre 1 et 12 :");
        mois = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + mois);

      
        
        } // fin de condition d'erreur N°2 
    
            if(annee > anneemax || annee < anneemin ){
        annee = 0;
        System.out.println("cette valeur est incorrecte,la valeur est trop haute rééseyez...");
        System.out.println("entrez le annee");
        System.out.println("Veuillez saisir un nombre compris entre -2200 et 2200 :");
        annee = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + annee+anneevaleur);
    
        } // fin de condition d'erreur N°2 
    
        int x = DecomptenombreDeJoursDepuis2000 (jour,mois,annee);
        System.out.println("Decompte des Jours Depuis 2000" + x);
        
        //int y = DecompteAnnee (jour,mois,annee);
    //         System.out.println("Decompte des Jours Depuis l'année" + y);    
    }
   
    

    // Fonction de décompte de jours jusque 1 er janvier 
    
    public static void DecompteAnnee(int jour,int mois,int annee) 
    {
        int jourjusquejanvier=0;
    switch(mois) {
        case 1:
        // Mois de janvier
        jourjusquejanvier = 31;  
        break;
    
        case 2:
        // Mois de février
        jourjusquejanvier =+ 28+31;
        break;
    
        case 3:
        // Mois de mars
        jourjusquejanvier =+ 31+28+31;
        break;   
  
        case 4:
        // Mois de avril
        jourjusquejanvier =+ 30+31+28+31;
        break;   
    
        case 5:
        // Mois de mai
        jourjusquejanvier =+ 31+30+31+28+31;
        break;   
    
        case 6:
        // Mois de juin
        jourjusquejanvier =+ 30+31+30+31+28+31;
        break;
    
        case 7:
        // Mois de juillet 31 jours et Aout aussi 31
        jourjusquejanvier =+ 31+30+31+30+31+28+31;
        break;
    
        case 8:
        // Mois de Aout 31j
        jourjusquejanvier =+ 31+31+30+31+30+31+28+31;
        break;
    
        case 9:
        // Mois de Septembre
        jourjusquejanvier =+ 30+31+31+30+31+30+31+28+31;
        break;
    
        case 10:
        // Mois de Octobre
        jourjusquejanvier =+ 31+30+31+31+30+31+30+31+28+31;
        break;
    
        case 11:
        // Mois de Novembre
        jourjusquejanvier =+ 30+31+30+31+31+30+31+30+31+28+31;
        break;
    
        case 12:
        // Mois de Décembre
        jourjusquejanvier =+ 31+30+31+30+31+31+30+31+30+31+28+31;
        break;
         
    } // fin de switch mois
} // fin de void 
   
    
    public static int DecomptenombreDeJoursDepuis2000(int jour,int mois,int annee) 
    {
    int nombreDeJours = 0;
    nombreDeJours = (annee-2000)*365;
    nombreDeJours += (int)  ((annee-2000)/4)+((annee-2000)%4)%2-20000;
    return(nombreDeJours);
    
    }
   

    
}

