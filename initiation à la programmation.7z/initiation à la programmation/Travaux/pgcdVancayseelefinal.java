package pgcdVancayseele;
import java.util.*;



public class pgcdVancayseele {

    
    public static void main(String[] args) {
   // classe scaner
               Scanner lectureClavier = new Scanner(System.in);
     
        
        // declaration des entiers 
        
        
        // nombre 1 : le dividande 
        int nbre1 = 299;
        
        // nombre 2 :  le diviseur
        int nbre2 = 130; 
       
        // reste 1Ã©re opÃ©ration 
        int reste1 = 0;
        
        // reste 2e opÃ©ration
        int reste2 = 0;
        
        int resultat =1;
        
        // timer 
        
// Programme 



               System.out.print("Entrez Le diviseur :");
               
            nbre1 = lectureClavier.nextInt();  // lire le premier mot 

      
            System.out.print("Entrez Le dividente :");
               
            nbre2 = lectureClavier.nextInt();  // lire le premier mot 

            
       // if (resultat!=0){           
         
                reste1 = nbre1%nbre2;
          //   System.out.println("PGCD  "+reste1);
           // while (reste1!=0){           
       
                    reste2 =nbre2 %reste1;
        
            // System.out.println("-------------------------------------------");
             //   System.out.println("PGCD "+reste2);
    
                //while (reste2!=0){
                        resultat=reste1%reste2;
        
                            System.out.println("-------------------------------------------");
                            System.out.println("le PGCD:"+resultat);
                           // System.out.println(launch);
                   
}    
                // } // end while21 
     
            
           // } // end while1
              
}    
      //2  } // end while

        
} // end lauch while

    