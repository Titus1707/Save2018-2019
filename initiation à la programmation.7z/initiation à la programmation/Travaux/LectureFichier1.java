package LectureFichier1;

import java.util.*;
import java.io.*;


public class LectureFichier1 {
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Hello");
        
        Scanner fichier = new Scanner (new File("zipcodes.csv"));
        String ligne;
        
        while (fichier.hasNext()){
            ligne = fichier.nextLine();
            System.out.println("Ligne Lue ;"+ligne);
    } // fin de while
        
        
    } // fin de main
    
} // fin du programme
