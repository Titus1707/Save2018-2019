/*
// calendrier , user entre la date et donne le jour
*/

package calendrier2;

// Gil Van Cayseele ISA A

import java.util.Scanner;

public class Calendrier2 
{          
    public static void main(String[] args) 
    {
        // classe scaner
        Scanner lectureClavier = new Scanner(System.in);
        // ASSIGNATION DES VARIABLES
        int jour=0;
        int mois= 0;
        int annee=0;
        // valeur maximale et min pour les jours 
        int jourmax = 31;
        int jourmin=1;
        int moismax = 12;
        int moismin=0;
        int anneemax = 2020;
        int anneemin=2000;
        String anneevaleur = "";
        int sommejours=0; 
        
        // calcul de la date du jour 
        
        // acceuil 
        System.out.println("//////////////////////////////////////////////////////////////////");
        System.out.println("    Programme de calendrier, veuillez entrer la date recherchee");
         
        System.out.println("//////////////////////////////////////////////////////////////////");
        
        // entrÃ©e du jour 
        System.out.println("---->  Entrez le jour  <----");
        System.out.println("/////////////////////////////////");
         
        //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        jour = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + jour);
        
        // entrÃ©e du mois 
        
        System.out.println("---->  Entrez le mois  <----");
        System.out.println("/////////////////////////////////");
         
         //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        mois = lectureClavier.nextInt();  // lire le premier mot 

        System.out.println("Vous avez saisi le nombre : " + mois);
        
        // entrÃ©e de l'annÃ©e 
        
        System.out.println("---->  Entrez l'annee  <----");
        System.out.println("/////////////////////////////////");
         
         //Scanner sc = new Scanner(System.in);
        System.out.println("Veuillez saisir un nombre :");
        annee = lectureClavier.nextInt();  // lire le premier mot 

        System.out.println("Vous avez saisi le nombre : " + annee+anneevaleur);
       
        
        System.out.println("---->  Vous avez rentré la date suivante  <----");
        System.out.println("////////////////////////////////////////////////");
        
        System.out.println("Date :"+mois+jour+annee);
        
        
        
        
        // AVant/Aprés JC
        if (annee <0){anneevaleur = "Avant Jésur-Christ";} // fin de avant jc
        if (annee ==0){
            System.out.println("----> ATTENTION L'ANNEE ZERO N'EXISTE PAS  <----");
            System.out.println("/////////////////////////////////");
            System.out.println("---->  RECOMMENCEZ  <----");
            System.out.println("/////////////////////////////////");
            System.out.println("---->  Entrez l'annee  <----");
            System.out.println("/////////////////////////////////");
            System.out.println("Veuillez saisir un nombre :");
            annee = lectureClavier.nextInt();  // lire le premier mot 
            System.out.println("Vous avez saisi le nombre : " + annee+anneevaleur);
        } // fin de fi anne ==0
        
        if(annee >0){anneevaleur ="Aprés Jésus-Christ";}
        
        
        if(jour > jourmax || jour < jourmin){
            jour = 0;
            System.out.println("cette valeur est incorrecte,la valeur est trop haute reeseyez...");
            System.out.println("entrez le jour");
            System.out.println("Veuillez saisir un nombre compris entre 1 et 31 :");
            jour = lectureClavier.nextInt();  // lire le premier mot 
            System.out.println("Vous avez saisi le nombre : " + jour);
        } // fin de condition d'erreur NÂ°2 
    
            if(mois > moismax || mois < moismin){
        mois = 0;
        System.out.println("cette valeur est incorrecte,la valeur est trop haute reeseyez...");
        System.out.println("entrez le mois");
        System.out.println("Veuillez saisir un nombre compris entre 1 et 12 :");
        mois = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + mois);

        } // fin de condition d'erreur NÂ°2 
    
            if(annee > anneemax || annee < anneemin ){
        annee = 0;
        System.out.println("cette valeur est incorrecte,la valeur est trop haute reeseyez...");
        System.out.println("entrez le annee");
        System.out.println("Veuillez saisir un nombre compris entre -2200 et 2200 :");
        annee = lectureClavier.nextInt();  // lire le premier mot 
        System.out.println("Vous avez saisi le nombre : " + annee+anneevaleur);
        
        
        } // fin de condition d'erreur NÂ°2 
    
        int x = DecomptenombreDeJoursDepuis2000 (jour,mois,annee);
       // System.out.println("---> Decompte des Jours Depuis 2000 <--" + x);
        
        int y = DecompteAnnee (jour, mois, annee);
        //System.out.println("Decompte des Jours Depuis l'annee " + y);
        sommejours= x+y;
   //     System.out.println(sommejours);
        String day = null;
        String daytype = null;
        
        daytype=Jourchoix(sommejours,day);
           
         System.out.println(daytype);
        //System.out.println("Decompte des Jours Depuis l'annee " + y);
        
        
    } // fin static void
   
    public static int DecompteAnnee(int jour,int mois,int annee) 
    {
        int jourjusquejanvier=jour;

        switch(mois) {
        case 2:
        // Mois de janvier
        jourjusquejanvier +=31 ;  
        break;
    
        case 3:
        // Mois de fevrier
        jourjusquejanvier += 28+31;
        break;
    
        case 4:
        // Mois de mars
        jourjusquejanvier += 31+28+31;
        break;   
  
        case 5:
        // Mois de avril
        jourjusquejanvier += +31+28+31+30;
        break;   
    
        case 6:
        // Mois de mai
        jourjusquejanvier += +30+31+28+31+31;
        break;   
    
        case 7:
        // Mois de juin
        jourjusquejanvier += 31+30+31+28+31+30;
        break;
    
        case 8:
        // Mois de juillet 31 jours et Aout aussi 31
        jourjusquejanvier +=30+31+30+31+28+31+30;
        break;
    
        case 9:
        // Mois de Aout 31j
        jourjusquejanvier += 31+30+31+30+31+28+31+30;
        break;
    
        case 10:
        // Mois de Septembre
        jourjusquejanvier += 31+31+30+31+30+31+28+31+30;
        break;
    
        case 11:
        // Mois de Octobre
        jourjusquejanvier += 31+31+31+30+31+30+31+28+31+30;
        break;
    
        case 12:
        // Mois de Novembre
        jourjusquejanvier += 31+30+31+31+30+31+30+31+28+31+31;
        break;
    
        } // fin switch
        
        if (mois >2 && (annee%4 == 0 && annee%100 !=0 || annee%400 ==0)){
            jourjusquejanvier += 1;
        } // fin if
    return(jourjusquejanvier-1);
    } // fin de switch mois
    
   
   
    public static int DecomptenombreDeJoursDepuis2000(int jour,int mois,int annee) {
    int nombreDeJours = 0;
    nombreDeJours = ((annee-2000)*365);
    nombreDeJours += (int)((annee-2000)/4)+((annee-2000)%4)%22;
    return(nombreDeJours);
    
    } // fin static int decomptenombredejoursdepuis2000 
   
    public static String Jourchoix (int sommejours,String day)
    {
    String daytype=null;    
    int jr;
    jr = sommejours%7;
    
    switch(jr) {
        case 0:
        daytype = "Jeudi";    
        break;
    
        case 1:
        daytype = "Vendredi";    
        break;
    
        case 2:
        daytype = "Samedi";
        break;
           
        case 3:
        daytype = "Dimanche";
        break;
        
        case 4:
        daytype = "Lundi";
        break;
        
        case 5:
        daytype = "Mardi";
        break;
        
        case 6:
        daytype="Mercredi";
        break;
        
        } // fin switch
     
     
        return daytype;
    
    
    } // end jourchoix
  
    
} // end public class calendrier