
package javaapplication23;

import java.util.*;



public class JavaApplication23 {

    public static void main(String[] args) {
        
        
       Scanner lectureClavier = new Scanner(System.in);
       
       int longeur,largeur,cote = 0,surface = 0,rayon;
       
       char choice;
     
                    
        // LECTEUR DU CLAVIER POUR LE CHOIX
        choice = lectureClavier.next().charAt(0);
        
        while (choice !='q'){
            
            switch (choice){       
            // Premier choix
            
            // Case a minuscule
            
                case 'a':
            System.out.println("vous avez choisit le A");
            System.out.println("------------------------------------------------------");
            cote = lectureClavier.nextInt();
            surface = SurfaceCarre(cote);
            System.out.println("Nous allons calculer le côté d'un carré de : "+cote+"cm de côté");
            System.out.println("------------------------------------------------------");
            System.out.println("la surface est de "+surface+"Cm²");
            
           
                case 'A' :
            cote = lectureClavier.nextInt();
            System.out.println("vous avez choisit le A");
            System.out.println("------------------------------------------------------");
            surface = SurfaceCarre(cote);
            System.out.println("Nous allons calculer la surface d'un carr� de  : "+cote+"cm de cote");
            System.out.println("------------------------------------------------------");
            System.out.println("la surface est de "+surface+"Cm²");
            break;
            
            
            
            //-----------------------------------------------------------------------------
            
            // deuxiéme choix
           
                
                case 'b': 
                
           System.out.println("vous avez choisit le b");
           System.out.println("Nous allons calculer la surface d'un rectange");
           // assignation de longeur et largeur 
           longeur = lectureClavier.nextInt();
           largeur = lectureClavier.nextInt();
           surface = SurfaceRectangle(12,20);
           System.out.println("l'aire du rectangle de longeur"+longeur+"et de largeur"+largeur+"pour une aire de "+surface+"cm²");
           System.out.println("la surface est de "+surface+"cm²");
            
                case 'B':
                
           System.out.println("vous avez choisit le B");
           System.out.println("Nous allons calculer la surface d'un rectange");
           // assignation de longeur et largeur 
            
           longeur = lectureClavier.nextInt();
           largeur = lectureClavier.nextInt();
           
           surface = SurfaceRectangle(12,20);
           
           System.out.println("l'aire du rectangle de longeur"+longeur+"et de largeur"+largeur+"pour une aire de "+surface+"cm²");
           System.out.println("la surface est de "+surface+"cm²");
           break;
            
            //---------------------------------------------------------------------------------
            
            // Troisiéme choix
            
                case 'q': 
           System.out.println("vous avez choisit le q");
           System.out.println("Au revoir cher utilisateur"); 
           
            
                case 'Q':
           System.out.println("vous avez choisit le Q");
           System.out.println("Goodbye");
           break;
           
            
                case 'C': 
           System.out.println("vous avez choisit le C, calculons le rayon d'un cercle");
           rayon = lectureClavier.nextInt(); 
           surface =SurfaceCercle(20);
           System.out.println("vous avez choisit le C, calculons le rayon d'un cercle");
           
            
                case 'c':
            System.out.println("vous avez choisit le Q");
           rayon = lectureClavier.nextInt();
           //surface = (int) (Math.PI*rayon);
           System.out.println("La surface est de");
           break;
           
            default : System.out.println("ERREUR");
            
            
        } // end switch
        
        } // end while
        
        lectureClavier.close();
    } // end static void

    
    
    public static int SurfaceCarre (int cote)
    {
    // fonction qui calcule la surface du carr�    
    return (cote*cote);
    
    } // fin de la fonctino SurfaceCarre
    
    public static int SurfaceRectangle (int longeur,int largeur)
    {
    // fonction qui calcule la surface du rectangle    
    return(longeur*largeur);
    
    }
    
    public static int SurfaceCercle (int rayon)
    {
    // fonction qui calcule la surface du rectangle    
    return(int) (Math.PI*(rayon*rayon));
    
    }
    
    
    
}// end java application
