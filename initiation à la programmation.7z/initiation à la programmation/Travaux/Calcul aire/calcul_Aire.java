
package calcul_Aire;
import java.util.*;

public class JavaApplication23 {

    public static void main(String[] args) {
       Scanner lectureClavier = new Scanner(System.in);
       
       int longeur,largeur,cote,surface = 0,rayon,pi;
       
       char choice;
    System.out.println("------------------------------------------------------");
    System.out.println("Programme qui calcule l'aire d'une forme géométrique");
    System.out.println("------------------------------------------------------");
    System.out.println("Pour calculer la surface d'un carré, Tapez 'A' ");
    System.out.println("Pour calculer la surface d'un rectangle, Tapez 'B' ");
    System.out.println("Pour calculer la surface d'un cercle, Tapez 'C' ");
    System.out.println("Pour quitter, Tapez 'Q' ");
    System.out.println("------------------------------------------------------");
    System.out.println("Entrez la lettre de votre choix :");
       
                    
        // LECTEUR DU CLAVIER POUR LE CHOIX
        choice = lectureClavier.next().charAt(0);
        
        while (choice !='q' | choice !='Q'){
            
        switch (choice){       
            // Premier choix
            
            // Case a minuscule
            
            case 'a':
                
            System.out.println("vous avez choisit le a");
            System.out.println("------------------------------------------------------");
            System.out.println("Maintenant, entrez les messures");
            cote = lectureClavier.nextInt();
            surface = cote*cote;
            System.out.println("Nous allons calculer le côté d'un carré de : "+cote+"cm de côté");
            System.out.println("------------------------------------------------------");
            System.out.println("la surface est de "+surface+"cm²");
            break;
           // Case A majuscule     
            case 'A' :
            cote = lectureClavier.nextInt();
            System.out.println("vous avez choisit le A");
            System.out.println("------------------------------------------------------");
            surface = cote*cote;
            System.out.println("Nous allons calculer le côté d'un carré de : "+cote+"cm de côté");
            System.out.println("------------------------------------------------------");
            System.out.println("la surface est de "+surface+"Cm²");
            
            break;
            
            
            // il y a un soucis ici l'orsque l'on utilise le A majuscule 
            
            //-----------------------------------------------------------------------------
            
            // deuxiéme choix
                case 'b': 
                
                System.out.println("vous avez choisit le b");
                System.out.println("Nous allons calculer la surface d'un rectange");
            
                 // assignation de longeur et largeur 
                System.out.println("Entrez la longeur"); 
                longeur = lectureClavier.nextInt();
                System.out.println("Entrez la Largeur");
                largeur = lectureClavier.nextInt();
           
                surface = longeur*largeur;
                System.out.println("l'aire du rectangle de longeur"+longeur+"et de largeur"+largeur+"pour une aire de "+surface+"cm²");
                System.out.println("la surface est de "+surface+"cm²");
            break;
                case 'B':
                
                System.out.println("vous avez choisit le B");
                System.out.println("Nous allons calculer la surface d'un rectange");
           
                 // assignation de longeur et largeur 
                System.out.println("Entrez la longeur"); 
                longeur = lectureClavier.nextInt();
                System.out.println("Entrez la Largeur");
                largeur = lectureClavier.nextInt();
                
                surface = longeur*largeur;
           
                System.out.println("l'aire du rectangle de longeur"+longeur+"et de largeur"+largeur+"pour une aire de "+surface+"cm²");
                System.out.println("la surface est de "+surface+"cm²");
                break;
            
                //---------------------------------------------------------------------------------
            
            case 'C' :
                
                System.out.println("vous avez choisit le c");
                System.out.println("entrez ke rayon du cercle"); 
                rayon = lectureClavier.nextInt();
                surface = (int) Math.PI*rayon*rayon;
                
                System.out.println("L'aire d'un cercle est de"+surface);
                break;
            case 'c' :
                
                System.out.println("vous avez choisit le c");
                System.out.println("entrez ke rayon du cercle"); 
                rayon = lectureClavier.nextInt();
                 surface = (int) Math.PI*rayon*rayon;
                
               System.out.println("L'aire d'un cercle est de"+surface);
                
                break;
                
            
            // Troisiéme choix
           case 'q': 
           System.out.println("vous avez choisit le q");
           System.out.println("Au revoir cher utilisateur"); 
           break;
           case 'Q':
           System.out.println("vous avez choisit le Q");
           System.out.println("Goodbye");
           
           break;
           // Quatriéme choix, aire d'un cercle 
           
                
                
        default : System.out.println("ERREUR");
             } // end switch
       
        
        } // end while
        System.out.println("la surface est de "+surface+"cm²");
        lectureClavier.close();
    } // end static void
////    
}// end java application
