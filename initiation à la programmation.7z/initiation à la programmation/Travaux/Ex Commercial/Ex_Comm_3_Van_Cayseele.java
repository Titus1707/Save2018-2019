package ex_comm_3_van_cayseele;

import java.util.*;

public class Ex_Comm_3_Van_Cayseele {

    public static void main(String[] args) {

        // déclaration des variables 
        // float
        float ventes, comm = 0, commpercue;
        // affiche le titre 
        System.out.println("----------------------------------------------------------------------------");
        System.out.println("-----Entrez le montant des ventes ----");
        System.out.println("----------------------------------------------------------------------------");

        boolean zero = true;

        Scanner sc = new Scanner(System.in);
        ventes = sc.nextFloat();

        while (ventes > 0) {

            // condition 1 , moins de 5000
            if (ventes <= 5000) {
                comm = (float) 0.005;

            }

            // condition 2 , 
            if (ventes > 5000 && ventes <= 10000) {
                comm = (float) 0.1;

            }

            if (ventes >= 10000) {
                comm = (float) 0.15;

            }

            System.out.println("----------------------------------------------------------------------------");
            System.out.println("les ventes du commercial sont de : " + ventes);  // affiche les ventes 
            System.out.println("----------------------------------------------------------------------------");
            System.out.println("la tranche de commision est de  : " + comm + " %");  // affiche les ventes
            System.out.println("----------------------------------------------------------------------------");

            // calcul de la commision
            commpercue = ventes * comm * 10;

            System.out.println("la commision percue par le vendeur est de  : " + commpercue + "€");  // affiche les ventes

        }

    }
}
