run:
Entrer la premi�re couleur : Marron
La couleur estMarron
Entrer la Seconde couleur : Noir
La couleur est Noir
Entrer la Troisi�me couleur : Rouge
La couleur estRouge
Entrer la derni�re couleur : Or
La couleur estOr
La valeur est de1.0Ohmsla tol�rance est de 5.0%
La valeur avec la tolerance positive est de6.0Ohms
La valeur avec la tolerance n�gative est de-4.0Ohms
BUILD SUCCESSFUL (total time: 10 seconds)
