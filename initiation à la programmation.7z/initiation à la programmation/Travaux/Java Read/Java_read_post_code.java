/*
Programme de lecture de codes postaux 
 */
package java_read_post_code;

// import librairies
     import java.util.*;
     import java.io.*;


public class Java_read_post_code {

    
    public static void main(String[] args) throws FileNotFoundException {
        
     System.out.println("hello");
     
     Scanner fichier = new Scanner (new File("zipcodes.cav"));
     String lignes;
     
     while (fichier.hasNext())
     {
         lignes = fichier.nextLine();
         System.out.println("Ligne lue : "+lignes);
     
     
     } // fin de while
     
     
    } // fin de void main
    
} // fin programme
